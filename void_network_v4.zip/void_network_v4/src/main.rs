//! VOID Neural Network v0.4 - TRUE FINITE
//! 
//! ONTOLOGICAL AUDIT v2:
//! - NO IEEE 754 floats anywhere in logic
//! - Decimal notation ("0.625") parsed directly to Ratio(625, 1000)
//! - Cross-multiplication comparison (no division)
//! - saturating_add for counters (no overflow wrap)
//! - Memory allocation costs budget
//!
//! KEY INSIGHT: "8.231" is NOT a float. It's 8231/1000.
//! The decimal point is just notation for "denominator is power of 10".
//! IEEE 754 is the heresy, not decimal notation.
//!
//! Philosophy:
//! - Every operation costs budget
//! - When budget = 0, stop and say "I don't know"
//! - Pattern matching, not matrix multiplication
//! - Network grows by accretion (coral architecture)
//!
//! Architecture:
//! - Layer 1: Transduction (fixed) - input → pattern
//! - Layer 2: Working Memory (3-7 hot orbits)
//! - Layer 3: Memory Bank (grows, hundreds of patterns)
//! - Layer 4: Economy (hit/miss, promotion/demotion)

use std::fs::File;
use std::io::BufReader;

// ============================================
// CORE TYPES - STRICTLY FINITE
// ============================================

/// Budget - the heartbeat of VOID. When it hits 0, observation stops.
#[derive(Debug, Clone, Copy)]
pub struct Budget(u32);

impl Budget {
    pub fn new(initial: u32) -> Self {
        Budget(initial)
    }
    
    /// Spend budget. Returns None if insufficient.
    pub fn spend(&mut self, cost: u32) -> Option<u32> {
        if self.0 >= cost {
            self.0 -= cost;
            Some(self.0)
        } else {
            None
        }
    }
    
    pub fn remaining(&self) -> u32 {
        self.0
    }
    
    pub fn is_exhausted(&self) -> bool {
        self.0 == 0
    }
}

/// Heat - accumulated cost, irreversible trace
#[derive(Debug, Clone, Copy, Default)]
pub struct Heat(u32);

impl Heat {
    pub fn add(&mut self, amount: u32) {
        self.0 = self.0.saturating_add(amount);
    }
    
    pub fn total(&self) -> u32 {
        self.0
    }
}

// ============================================
// RATIO - TRUE FINITE ARITHMETIC
// ============================================

/// Ratio represents certainty in VOID.
/// 
/// KEY INSIGHT: Decimal notation is NOT floating point!
/// "0.625" is just shorthand for 625/1000.
/// The heresy is IEEE 754, not the decimal point.
///
/// This struct stores n/d and NEVER converts to float internally.
/// Display can show decimals (for human convenience) but all
/// comparisons use cross-multiplication.
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub struct Ratio {
    pub n: u32,  // numerator
    pub d: u32,  // denominator
}

impl Ratio {
    pub fn new(n: u32, d: u32) -> Self {
        if d == 0 { 
            Ratio { n: 0, d: 1 } 
        } else { 
            Ratio { n, d } 
        }
    }
    
    pub fn zero() -> Self { 
        Ratio { n: 0, d: 1 } 
    }
    
    /// Parse decimal string DIRECTLY to Ratio.
    /// NO IEEE 754 INVOLVED AT ANY POINT!
    /// 
    /// "8.231" → Ratio(8231, 1000)
    /// "0.5"   → Ratio(5, 10)
    /// "42"    → Ratio(42, 1)
    /// 
    /// This is the TRUE finite way to handle decimals.
    pub fn from_decimal_str(s: &str) -> Option<Self> {
        let s = s.trim();
        let parts: Vec<&str> = s.split('.').collect();
        
        match parts.len() {
            1 => {
                // "42" → 42/1
                let n: u32 = parts[0].parse().ok()?;
                Some(Ratio::new(n, 1))
            }
            2 => {
                // "8.231" → 8231/1000
                let whole_str = parts[0];
                let frac_str = parts[1];
                
                let decimals = frac_str.len() as u32;
                let denom = 10u32.checked_pow(decimals)?;
                
                let whole: u32 = if whole_str.is_empty() { 0 } else { whole_str.parse().ok()? };
                let frac: u32 = if frac_str.is_empty() { 0 } else { frac_str.parse().ok()? };
                
                let n = whole.checked_mul(denom)?.checked_add(frac)?;
                Some(Ratio::new(n, denom))
            }
            _ => None
        }
    }
    
    /// Convenience: create from integer numerator and denominator
    pub fn frac(n: u32, d: u32) -> Self {
        Ratio::new(n, d)
    }
    
    /// Cross-multiplication comparison: a/b >= c/d <=> a*d >= c*b
    /// NO DIVISION! This is the key to finite arithmetic.
    /// 
    /// Cost: 1 budget (multiplication is work)
    pub fn ge(&self, other: &Ratio, budget: &mut Budget) -> Option<bool> {
        budget.spend(1)?;
        let left = self.n as u64 * other.d as u64;
        let right = other.n as u64 * self.d as u64;
        Some(left >= right)
    }
    
    /// Greater than comparison
    pub fn gt(&self, other: &Ratio, budget: &mut Budget) -> Option<bool> {
        budget.spend(1)?;
        let left = self.n as u64 * other.d as u64;
        let right = other.n as u64 * self.d as u64;
        Some(left > right)
    }
    
    /// Display as decimal string (for human eyes only!)
    /// This is the ONLY place we do division, and only for display.
    pub fn to_decimal_string(&self, precision: usize) -> String {
        if self.d == 0 { return "0".to_string(); }
        
        // Integer division with remainder for decimal places
        let whole = self.n / self.d;
        let remainder = self.n % self.d;
        
        if remainder == 0 || precision == 0 {
            return whole.to_string();
        }
        
        // Calculate decimal places using integer arithmetic
        let mut frac_str = String::new();
        let mut rem = remainder;
        for _ in 0..precision {
            rem *= 10;
            frac_str.push_str(&(rem / self.d).to_string());
            rem %= self.d;
            if rem == 0 { break; }
        }
        
        format!("{}.{}", whole, frac_str)
    }
    
    /// Display as percentage (for human eyes only!)
    pub fn to_percent_string(&self, precision: usize) -> String {
        if self.d == 0 { return "0%".to_string(); }
        
        // Multiply by 100 first (still integer!)
        let percent_n = self.n as u64 * 100;
        let percent_d = self.d as u64;
        
        let whole = percent_n / percent_d;
        let remainder = percent_n % percent_d;
        
        if remainder == 0 || precision == 0 {
            return format!("{}%", whole);
        }
        
        let mut frac_str = String::new();
        let mut rem = remainder;
        for _ in 0..precision {
            rem *= 10;
            frac_str.push_str(&(rem / percent_d).to_string());
            rem %= percent_d;
            if rem == 0 { break; }
        }
        
        format!("{}.{}%", whole, frac_str)
    }
    
    /// Display as fraction string
    pub fn to_fraction_string(&self) -> String {
        format!("{}/{}", self.n, self.d)
    }
    
    /// Simplify the ratio using GCD (optional, for cleaner display)
    pub fn simplified(&self) -> Self {
        let g = gcd(self.n, self.d);
        if g == 0 { return *self; }
        Ratio::new(self.n / g, self.d / g)
    }
}

/// Greatest Common Divisor (Euclidean algorithm) - pure integer arithmetic
fn gcd(mut a: u32, mut b: u32) -> u32 {
    while b != 0 {
        let t = b;
        b = a % b;
        a = t;
    }
    a
}

// ============================================
// ENTROPY MAP - void_entropy.v (SCALED INTEGER VERSION)
// ============================================

/// EntropyMap tracks global symptom rarity.
/// Uses SCALED INTEGERS, not floats.
pub struct EntropyMap {
    pub symptom_counts: Vec<u32>,
    pub total_samples: u32,
    pub scale: u32,
}

impl EntropyMap {
    pub fn new(num_symptoms: usize) -> Self {
        EntropyMap {
            symptom_counts: vec![0; num_symptoms],
            total_samples: 0,
            scale: 1000,
        }
    }

    pub fn train(&mut self, patterns: &[Pattern]) {
        self.total_samples = patterns.len() as u32;
        
        for p in patterns {
            for (i, &present) in p.symptoms.iter().enumerate() {
                if present {
                    if i >= self.symptom_counts.len() {
                        self.symptom_counts.resize(i + 1, 0);
                    }
                    self.symptom_counts[i] = self.symptom_counts[i].saturating_add(1);
                }
            }
        }
        
        // Debug output
        let mut rarity: Vec<(usize, u32)> = self.symptom_counts.iter()
            .enumerate()
            .filter(|(_, &c)| c > 0)
            .map(|(i, &c)| (i, c))
            .collect();
        rarity.sort_by_key(|(_, c)| *c);
        
        println!("\n[EntropyMap] Trained on {} patterns (scale={})", self.total_samples, self.scale);
        println!("[EntropyMap] Top 5 RAREST symptoms:");
        for (i, (idx, count)) in rarity.iter().take(5).enumerate() {
            let weight = self.get_weight(*idx);
            println!("  {}. symptom[{}]: count={}, weight={}", i+1, idx, count, weight);
        }
        println!("[EntropyMap] Top 5 COMMON symptoms:");
        for (i, (idx, count)) in rarity.iter().rev().take(5).enumerate() {
            let weight = self.get_weight(*idx);
            println!("  {}. symptom[{}]: count={}, weight={}", i+1, idx, count, weight);
        }
        println!();
    }

    /// Get integer weight for symptom.
    pub fn get_weight(&self, symptom_idx: usize) -> u32 {
        let count = self.symptom_counts.get(symptom_idx).copied().unwrap_or(0);
        (self.scale * self.total_samples) / (count.saturating_add(1))
    }
}

// ============================================
// PATTERN
// ============================================

#[derive(Debug, Clone)]
pub struct Pattern {
    pub name: String,
    pub symptoms: Vec<bool>,
    pub strength: u32,
}

impl Pattern {
    pub fn new(name: String, symptoms: Vec<bool>) -> Self {
        Pattern { name, symptoms, strength: 1 }
    }
    
    /// Entropy-weighted comparison returning Ratio
    pub fn compare(&self, other: &[bool], entropy: &EntropyMap, budget: &mut Budget, heat: &mut Heat) -> Option<Ratio> {
        let mut intersection_score: u64 = 0;
        let mut union_score: u64 = 0;
        
        for (i, (a, b)) in self.symptoms.iter().zip(other.iter()).enumerate() {
            budget.spend(1)?;
            heat.add(1);
            
            let weight = entropy.get_weight(i) as u64;
            let a_present = *a;
            let b_present = *b;
            
            if a_present || b_present {
                union_score = union_score.saturating_add(weight);
                if a_present && b_present {
                    intersection_score = intersection_score.saturating_add(weight);
                }
            }
        }
        
        let n = intersection_score.min(u32::MAX as u64) as u32;
        let d = union_score.min(u32::MAX as u64) as u32;
        
        Some(Ratio::new(n, d))
    }
}

// ============================================
// ORBIT
// ============================================

#[derive(Debug, Clone)]
pub struct Orbit {
    pub pattern: Pattern,
    pub hits: u32,
    pub misses: u32,
}

impl Orbit {
    pub fn new(pattern: Pattern) -> Self {
        Orbit { pattern, hits: 0, misses: 0 }
    }
    
    pub fn strength(&self) -> Ratio {
        let total = self.hits.saturating_add(self.misses);
        if total == 0 {
            Ratio::new(1, 1)
        } else {
            Ratio::new(self.hits, total)
        }
    }
    
    pub fn record_hit(&mut self) {
        self.hits = self.hits.saturating_add(1);
    }
    
    pub fn record_miss(&mut self) {
        self.misses = self.misses.saturating_add(1);
    }
}

// ============================================
// VOID NETWORK
// ============================================

pub struct VoidNetwork {
    pub orbits: Vec<Orbit>,
    pub max_orbits: usize,
    pub memory_bank: Vec<Pattern>,
    pub entropy: EntropyMap,
    
    pub match_threshold: Ratio,
    pub demotion_threshold: Ratio,
    pub alloc_cost: u32,
}

#[derive(Debug)]
pub enum InferenceResult {
    Match { 
        diagnosis: String, 
        confidence: Ratio,
        budget_spent: u32 
    },
    DontKnow { 
        budget_spent: u32, 
        patterns_checked: u32 
    },
    Exhausted { 
        partial_best: Option<String>, 
        budget_spent: u32 
    },
}

impl VoidNetwork {
    pub fn new() -> Self {
        VoidNetwork {
            orbits: Vec::new(),
            max_orbits: 7,
            memory_bank: Vec::new(),
            entropy: EntropyMap::new(0),
            // Using from_decimal_str - NO FLOATS!
            match_threshold: Ratio::from_decimal_str("0.5").unwrap(),    // 5/10 = 1/2
            demotion_threshold: Ratio::from_decimal_str("0.3").unwrap(), // 3/10
            alloc_cost: 10,
        }
    }
    
    /// Create with custom threshold (parsed from decimal string)
    pub fn with_threshold(threshold: &str) -> Self {
        let mut net = VoidNetwork::new();
        if let Some(t) = Ratio::from_decimal_str(threshold) {
            net.match_threshold = t;
        }
        net
    }
    
    pub fn load_patterns_free(&mut self, patterns: Vec<Pattern>) {
        let num_symptoms = patterns.get(0).map(|p| p.symptoms.len()).unwrap_or(0);
        self.entropy = EntropyMap::new(num_symptoms);
        self.entropy.train(&patterns);
        self.memory_bank = patterns;
        println!("Loaded {} patterns into memory bank", self.memory_bank.len());
    }
    
    fn transduce(&self, symptoms: Vec<bool>, budget: &mut Budget, heat: &mut Heat) -> Option<Vec<bool>> {
        budget.spend(1)?;
        heat.add(1);
        Some(symptoms)
    }
    
    fn check_orbits(&mut self, input: &[bool], budget: &mut Budget, heat: &mut Heat) -> Option<(String, Ratio)> {
        for orbit in &mut self.orbits {
            if let Some(confidence) = orbit.pattern.compare(input, &self.entropy, budget, heat) {
                match confidence.ge(&self.match_threshold, budget) {
                    Some(true) => {
                        orbit.record_hit();
                        println!("    [ORBIT HIT] {} (confidence: {} = {})", 
                                 orbit.pattern.name, 
                                 confidence.to_fraction_string(),
                                 confidence.to_percent_string(1));
                        return Some((orbit.pattern.name.clone(), confidence));
                    }
                    Some(false) => {
                        orbit.record_miss();
                    }
                    None => {
                        return None;
                    }
                }
            } else {
                return None;
            }
        }
        None
    }
    
    fn search_memory_bank(&mut self, input: &[bool], budget: &mut Budget, heat: &mut Heat) -> Option<(String, Ratio, usize)> {
        let mut best_match: Option<(String, Ratio, usize)> = None;
        let debug_threshold = Ratio::from_decimal_str("0.3").unwrap();
        
        for (idx, pattern) in self.memory_bank.iter().enumerate() {
            if budget.is_exhausted() {
                break;
            }
            
            if let Some(confidence) = pattern.compare(input, &self.entropy, budget, heat) {
                if let Some(true) = confidence.gt(&debug_threshold, budget) {
                    println!("    [DEBUG] {} → {} = {}",
                             pattern.name, 
                             confidence.to_fraction_string(),
                             confidence.to_percent_string(1));
                }
                
                match confidence.ge(&self.match_threshold, budget) {
                    Some(true) => {
                        let dominated = if let Some((_, ref best_conf, _)) = best_match {
                            confidence.gt(best_conf, budget).unwrap_or(false)
                        } else {
                            true
                        };
                        
                        if dominated {
                            best_match = Some((pattern.name.clone(), confidence, idx));
                        }
                    }
                    Some(false) => {}
                    None => break,
                }
            } else {
                break;
            }
        }
        
        best_match
    }
    
    fn maybe_promote(&mut self, pattern_idx: usize, budget: &mut Budget) {
        if budget.spend(self.alloc_cost).is_none() {
            println!("  → Cannot promote (insufficient budget)");
            return;
        }
        
        if self.orbits.len() < self.max_orbits {
            let pattern = self.memory_bank[pattern_idx].clone();
            self.orbits.push(Orbit::new(pattern));
            println!("  → Promoted '{}' to working memory", self.memory_bank[pattern_idx].name);
        } else {
            let mut weakest_idx = 0;
            let mut weakest_strength = self.orbits[0].strength();
            
            for (i, orbit) in self.orbits.iter().enumerate().skip(1) {
                let strength = orbit.strength();
                if let Some(true) = weakest_strength.gt(&strength, budget) {
                    weakest_idx = i;
                    weakest_strength = strength;
                }
            }
            
            if let Some(true) = self.demotion_threshold.gt(&weakest_strength, budget) {
                let demoted = self.orbits.remove(weakest_idx);
                println!("  → Demoted '{}' (strength: {})", 
                         demoted.pattern.name, weakest_strength.to_fraction_string());
                
                let pattern = self.memory_bank[pattern_idx].clone();
                self.orbits.push(Orbit::new(pattern));
                println!("  → Promoted '{}' to working memory", self.memory_bank[pattern_idx].name);
            }
        }
    }
    
    pub fn infer(&mut self, symptoms: Vec<bool>, mut budget: Budget) -> InferenceResult {
        let initial_budget = budget.remaining();
        let mut heat = Heat::default();
        let mut patterns_checked = 0u32;
        
        let input = match self.transduce(symptoms, &mut budget, &mut heat) {
            Some(p) => p,
            None => return InferenceResult::Exhausted { 
                partial_best: None, 
                budget_spent: initial_budget 
            },
        };
        
        if let Some((diagnosis, confidence)) = self.check_orbits(&input, &mut budget, &mut heat) {
            return InferenceResult::Match {
                diagnosis,
                confidence,
                budget_spent: initial_budget - budget.remaining(),
            };
        }
        patterns_checked = self.orbits.len() as u32;
        
        if let Some((diagnosis, confidence, idx)) = self.search_memory_bank(&input, &mut budget, &mut heat) {
            self.maybe_promote(idx, &mut budget);
            
            return InferenceResult::Match {
                diagnosis,
                confidence,
                budget_spent: initial_budget - budget.remaining(),
            };
        }
        
        let budget_spent = initial_budget - budget.remaining();
        
        if budget.is_exhausted() {
            InferenceResult::Exhausted {
                partial_best: None,
                budget_spent,
            }
        } else {
            InferenceResult::DontKnow {
                budget_spent,
                patterns_checked: patterns_checked.saturating_add(self.memory_bank.len() as u32),
            }
        }
    }
    
    pub fn status(&self) {
        println!("\n=== VOID Network Status (TRUE FINITE v0.4) ===");
        println!("Working Memory (Orbits): {}/{}", self.orbits.len(), self.max_orbits);
        for (i, orbit) in self.orbits.iter().enumerate() {
            let strength = orbit.strength();
            println!("  [{}] {} (strength: {} = {}, hits: {}, misses: {})", 
                     i, orbit.pattern.name, 
                     strength.to_fraction_string(),
                     strength.to_percent_string(1),
                     orbit.hits, orbit.misses);
        }
        println!("Memory Bank: {} patterns", self.memory_bank.len());
        println!("Match Threshold: {} = {}", 
                 self.match_threshold.to_fraction_string(),
                 self.match_threshold.to_percent_string(1));
        println!("================================================\n");
    }
}

// ============================================
// DATA LOADING
// ============================================

fn load_csv(path: &str) -> Result<Vec<Pattern>, Box<dyn std::error::Error>> {
    let file = File::open(path)?;
    let mut reader = csv::Reader::from_reader(BufReader::new(file));
    
    let mut patterns = Vec::new();
    
    for result in reader.records() {
        let record = result?;
        let diagnosis = record.get(0).unwrap_or("unknown").to_string();
        let symptoms: Vec<bool> = record.iter()
            .skip(1)
            .map(|s| s == "1")
            .collect();
        patterns.push(Pattern::new(diagnosis, symptoms));
    }
    
    Ok(patterns)
}

// ============================================
// MAIN
// ============================================

fn main() {
    println!("╔════════════════════════════════════════════════════════╗");
    println!("║      VOID Neural Network v0.4 - TRUE FINITE            ║");
    println!("║  Decimal strings parsed to Ratio (NO IEEE 754!)        ║");
    println!("║  \"0.625\" → 625/1000, not floating point               ║");
    println!("║  Cross-multiplication • saturating_add                 ║");
    println!("║  'I don't know' is a valid answer                     ║");
    println!("╚════════════════════════════════════════════════════════╝\n");
    
    println!("ONTOLOGICAL AUDIT v2:");
    println!("  ✓ NO IEEE 754 floats anywhere");
    println!("  ✓ Decimal notation parsed directly: \"0.5\" → Ratio(5, 10)");
    println!("  ✓ All comparisons via cross-multiplication");
    println!("  ✓ Division only for final display to humans");
    println!("  ✓ saturating_add prevents overflow");
    println!();
    
    // Demo: parsing decimal strings
    println!("=== Ratio from decimal strings (NO FLOATS) ===");
    let examples = ["0.5", "0.625", "0.333", "1.0", "0.1"];
    for s in examples {
        if let Some(r) = Ratio::from_decimal_str(s) {
            let simplified = r.simplified();
            println!("  \"{}\" → {} → simplified: {} = {}", 
                     s, r.to_fraction_string(), 
                     simplified.to_fraction_string(),
                     simplified.to_percent_string(2));
        }
    }
    println!();
    
    // Load data
    let patterns = match load_csv("disease_symptoms_sample.csv") {
        Ok(p) => p,
        Err(e) => {
            eprintln!("Error loading data: {}", e);
            return;
        }
    };
    
    println!("Loaded {} disease patterns\n", patterns.len());
    
    // Create network
    let mut network = VoidNetwork::new();
    
    // Split data
    let train_size = 200.min(patterns.len());
    let (train, test) = patterns.split_at(train_size);
    
    network.load_patterns_free(train.to_vec());
    network.status();
    
    // Test inference
    println!("=== Testing Inference (TRUE FINITE) ===\n");
    
    let mut correct = 0u32;
    let mut wrong = 0u32;
    let mut dont_know = 0u32;
    
    for (i, test_pattern) in test.iter().take(10).enumerate() {
        let budget = Budget::new(100000);
        
        println!("Test {}: Looking for '{}'", i + 1, test_pattern.name);
        
        let result = network.infer(test_pattern.symptoms.clone(), budget);
        
        match result {
            InferenceResult::Match { diagnosis, confidence, budget_spent } => {
                let is_correct = diagnosis == test_pattern.name;
                println!("  → Match: {} (confidence: {} = {}, budget: {})", 
                         diagnosis, 
                         confidence.to_fraction_string(),
                         confidence.to_percent_string(1),
                         budget_spent);
                if is_correct {
                    println!("  → ✓ CORRECT");
                    correct = correct.saturating_add(1);
                } else {
                    println!("  → ✗ WRONG (but may be medically related)");
                    wrong = wrong.saturating_add(1);
                }
            }
            InferenceResult::DontKnow { budget_spent, patterns_checked } => {
                println!("  → I DON'T KNOW (checked {} patterns, budget: {})", 
                         patterns_checked, budget_spent);
                println!("  → This is honest - no confident match found");
                dont_know = dont_know.saturating_add(1);
            }
            InferenceResult::Exhausted { partial_best, budget_spent } => {
                println!("  → EXHAUSTED (budget: {}, partial: {:?})", 
                         budget_spent, partial_best);
            }
        }
        println!();
    }
    
    // Final status
    network.status();
    
    println!("═══════════════════════════════════════════════════════════");
    println!("RESULTS: {} correct, {} wrong, {} 'I don't know'", correct, wrong, dont_know);
    println!("═══════════════════════════════════════════════════════════");
    println!();
    println!("v0.4 TRUE FINITE:");
    println!("- \"0.5\" is NOT a float, it's 5/10 = 1/2");
    println!("- IEEE 754 is the heresy, not decimal notation");
    println!("- All arithmetic is integer until final display");
    println!();
    println!("The decimal point is just notation.");
    println!("Maat weighs ratios. Pascal's floats can go to hell.");
}
